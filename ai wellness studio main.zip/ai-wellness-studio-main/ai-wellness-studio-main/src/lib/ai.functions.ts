import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  context: z.enum(["farmer_post", "calculator", "buyer"]),
  wasteLabel: z.string().max(60),
  tons: z.number().min(0).max(100000),
  governorate: z.string().max(40).optional(),
  pricePerTon: z.number().min(0).max(1000000).optional(),
});

const INSTRUCTIONS = `أنت خبير مصري في الزراعة المستدامة وتدوير المخلفات الزراعية تعمل لمنصة "تدوير".
اكتب بالعربية الفصحى المبسطة الموجهة للفلاح أو المشتري المصري.
قدّم من 4 إلى 5 نصائح عملية قصيرة ومحددة (كل نصيحة سطر يبدأ بـ "- ")، تراعي نوع المخلف والكمية والمحافظة والموسم في مصر:
طرق التخزين والكبس، توقيت البيع، كيف يرفع السعر، الاستخدامات الأعلى قيمة، ومخاطر الحرق والغرامات.
لا تستخدم عناوين ولا رموز تنسيق غير "- ". لا تخترع أرقاماً رسمية دقيقة؛ استخدم صيغة تقريبية عند الحاجة.`;

export const getAiAdvice = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env['LOVABLE_API_KEY'];
    if (!apiKey) return { ok: false as const, error: "خدمة الذكاء الاصطناعي غير مهيأة." };
    const who = data.context === "buyer" ? "مشترٍ (مصنع أعلاف/أسمدة/طاقة حيوية)" : "فلاح";
    const prompt = `المستخدم: ${who}
نوع المخلف: ${data.wasteLabel}
الكمية: ${data.tons} طن
${data.governorate ? `المحافظة: ${data.governorate}` : ""}
${data.pricePerTon ? `السعر المطلوب للطن: ${data.pricePerTon} جنيه` : ""}
أعطني نصائح مخصصة لهذه الحالة.`;
    try {
      const { generateAdvice } = await import("./ai.server");
      const text = await generateAdvice(apiKey, INSTRUCTIONS, prompt);
      return { ok: true as const, text };
    } catch (e) {
      return { ok: false as const, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع." };
    }
  });

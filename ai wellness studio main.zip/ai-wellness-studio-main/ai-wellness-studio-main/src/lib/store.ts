import { useEffect, useState } from "react";
import { COMMISSION_RATE, WASTE_TYPES, type WasteType } from "@/config/tadweer";

export interface Listing {
  id: string;
  type: WasteType;
  tons: number;
  governorate: string;
  pricePerTon: number;
  availableFrom: string;
  phone: string;
  notes?: string | undefined;
  farmer: string;
  createdAt: number;
}

export interface Deal {
  id: string;
  listingId: string;
  type: WasteType;
  tons: number;
  pricePerTon: number;
  total: number;
  commission: number;
  farmerGets: number;
  co2Kg: number;
  governorate: string;
  createdAt: number;
}

export type Role = "farmer" | "buyer";

const K = { listings: "tadweer.listings.v1", deals: "tadweer.deals.v1", role: "tadweer.role" };

const day = 86400000;
const BASE = Date.UTC(2026, 9, 15);

function seedListings(): Listing[] {
  const rows: [WasteType, number, string, number, string][] = [
    ["rice_straw", 40, "كفر الشيخ", 850, "الحاج محمود"],
    ["rice_straw", 25, "الدقهلية", 900, "عبد الرحمن سالم"],
    ["corn_stalks", 18, "المنيا", 650, "أحمد فتحي"],
    ["bagasse", 60, "قنا", 1100, "جمعية نجع حمادي"],
    ["palm", 12, "أسوان", 550, "إبراهيم النوبي"],
    ["manure", 30, "الشرقية", 420, "مزرعة السلام"],
    ["rice_straw", 55, "البحيرة", 800, "سعيد الشافعي"],
    ["corn_stalks", 22, "أسيوط", 700, "محمد عبد العال"],
    ["bagasse", 35, "سوهاج", 1250, "حسن رزق"],
    ["palm", 20, "الأقصر", 600, "مزارع الكرنك"],
    ["manure", 15, "المنوفية", 380, "خالد عيد"],
    ["rice_straw", 70, "الغربية", 780, "جمعية طنطا الزراعية"],
    ["corn_stalks", 10, "الفيوم", 620, "رمضان جابر"],
    ["manure", 45, "الدقهلية", 450, "مزرعة النيل"],
    ["rice_straw", 33, "الشرقية", 870, "يوسف عبد الله"],
    ["palm", 28, "بني سويف", 520, "علي حمدان"],
    ["bagasse", 50, "المنيا", 1050, "مصنع أبو قرقاص"],
    ["corn_stalks", 16, "القليوبية", 720, "سامي توفيق"],
  ];
  return rows.map(([type, tons, governorate, pricePerTon, farmer], i) => ({
    id: `seed-${i + 1}`,
    type, tons, governorate, pricePerTon, farmer,
    availableFrom: new Date(BASE + (i % 6) * day).toISOString().slice(0, 10),
    phone: `0100${String(1000000 + i * 37731).slice(0, 7)}`,
    createdAt: BASE - i * day * 0.7,
  }));
}

function seedDeals(): Deal[] {
  const rows: [WasteType, number, number, string, number][] = [
    ["rice_straw", 20, 820, "كفر الشيخ", 160],
    ["bagasse", 30, 1100, "قنا", 130],
    ["corn_stalks", 12, 650, "المنيا", 95],
    ["rice_straw", 35, 800, "البحيرة", 60],
    ["manure", 25, 400, "الشرقية", 40],
    ["palm", 10, 560, "أسوان", 20],
    ["rice_straw", 18, 880, "الدقهلية", 8],
  ];
  return rows.map(([type, tons, price, governorate, ago], i) => makeDeal(`seed-deal-${i}`, `seed-${i}`, type, tons, price, governorate, BASE - ago * day));
}

export function makeDeal(id: string, listingId: string, type: WasteType, tons: number, pricePerTon: number, governorate: string, createdAt: number): Deal {
  const total = tons * pricePerTon;
  const commission = Math.round(total * COMMISSION_RATE);
  return { id, listingId, type, tons, pricePerTon, total, commission, farmerGets: total - commission, co2Kg: tons * WASTE_TYPES[type].co2PerTon, governorate, createdAt };
}

function read<T>(key: string, fallback: () => T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (raw) return JSON.parse(raw) as T;
    const v = fallback();
    window.localStorage.setItem(key, JSON.stringify(v));
    return v;
  } catch {
    return fallback();
  }
}
function write(key: string, v: unknown) {
  try { window.localStorage.setItem(key, JSON.stringify(v)); } catch { /* ignore */ }
  window.dispatchEvent(new Event("tadweer:change"));
}

export function getListings() { return read<Listing[]>(K.listings, seedListings); }
export function getDeals() { return read<Deal[]>(K.deals, seedDeals); }
export function getRole(): Role { try { return (localStorage.getItem(K.role) as Role) || "farmer"; } catch { return "farmer"; } }
export function setRole(r: Role) { try { localStorage.setItem(K.role, r); } catch { /* */ } window.dispatchEvent(new Event("tadweer:change")); }

export function addListing(l: Omit<Listing, "id" | "createdAt">) {
  const item: Listing = { ...l, id: `l-${Date.now()}`, createdAt: Date.now() };
  write(K.listings, [item, ...getListings()]);
  return item;
}

export function completeDeal(listing: Listing, tons: number) {
  const deal = makeDeal(`d-${Date.now()}`, listing.id, listing.type, tons, listing.pricePerTon, listing.governorate, Date.now());
  write(K.listings, getListings().map((l) => (l.id === listing.id ? { ...l, tons: +(l.tons - tons).toFixed(2) } : l)));
  write(K.deals, [deal, ...getDeals()]);
  return deal;
}

/** Client-only reactive snapshot; null before hydration. */
export function useTadweer() {
  const [s, setS] = useState<{ listings: Listing[]; deals: Deal[]; role: Role } | null>(null);
  useEffect(() => {
    const load = () => setS({ listings: getListings(), deals: getDeals(), role: getRole() });
    load();
    window.addEventListener("tadweer:change", load);
    window.addEventListener("storage", load);
    return () => { window.removeEventListener("tadweer:change", load); window.removeEventListener("storage", load); };
  }, []);
  return s;
}

export function totals(deals: Deal[]) {
  return deals.reduce((a, d) => ({ tons: a.tons + d.tons, co2: a.co2 + d.co2Kg, income: a.income + d.farmerGets, commission: a.commission + d.commission }), { tons: 0, co2: 0, income: 0, commission: 0 });
}

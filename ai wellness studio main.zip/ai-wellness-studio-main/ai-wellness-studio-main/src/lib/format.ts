const nf = new Intl.NumberFormat("ar-EG", { maximumFractionDigits: 1 });
export const num = (n: number) => nf.format(n);
export const money = (n: number) => `${nf.format(Math.round(n))} جنيه`;
export const tons = (n: number) => `${nf.format(n)} طن`;

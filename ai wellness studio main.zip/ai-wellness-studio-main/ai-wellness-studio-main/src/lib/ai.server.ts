import { createOpenAI } from "@ai-sdk/openai";
import { streamText } from "ai";

const MODEL = "openai/gpt-6-astra";
const BASE_URL = "https://ai.gateway.lovable.dev/v1";

export class AiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

/** Streams a Responses call server-side and returns the final text. */
export async function generateAdvice(apiKey: string, instructions: string, prompt: string) {
  const provider = createOpenAI({
    baseURL: BASE_URL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
  });
  let streamError: unknown;
  const result = streamText({
    model: provider.responses(MODEL),
    instructions,
    messages: [{ role: "user", content: prompt }],
    onError: ({ error }) => { streamError = error; },
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });
  let text = "";
  for await (const chunk of result.textStream) text += chunk;
  if (!text.trim()) {
    const e = streamError as { statusCode?: number; message?: string } | undefined;
    const status = e?.statusCode ?? 500;
    if (status === 402) throw new AiError(402, "نفد رصيد الذكاء الاصطناعي. يرجى إضافة رصيد ثم المحاولة لاحقاً.");
    if (status === 429) throw new AiError(429, "ضغط كبير على الخدمة الآن، حاول بعد قليل.");
    if (status === 403) throw new AiError(403, "خدمة الذكاء الاصطناعي غير متاحة حالياً لهذا الحساب.");
    throw new AiError(status, "تعذر توليد النصائح الآن، حاول مرة أخرى بعد قليل.");
  }
  return text.trim();
}

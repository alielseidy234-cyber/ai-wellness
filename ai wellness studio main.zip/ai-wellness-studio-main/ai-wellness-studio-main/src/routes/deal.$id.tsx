import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, CreditCard, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AiAdvice } from "@/components/AiAdvice";
import { COMMISSION_RATE, WASTE_TYPES } from "@/config/tadweer";
import { completeDeal, useTadweer, type Deal } from "@/lib/store";
import { money, num, tons } from "@/lib/format";

export const Route = createFileRoute("/deal/$id")({
  head: () => ({
    meta: [
      { title: "إتمام الصفقة — تدوير" },
      { name: "description", content: "راجع تفاصيل الصفقة والعمولة والأثر البيئي قبل التأكيد." },
      { property: "og:title", content: "إتمام الصفقة — تدوير" },
      { property: "og:description", content: "صفقة مخلفات زراعية شفافة بعمولة 4%." },
    ],
  }),
  component: DealPage,
});

function DealPage() {
  const { id } = Route.useParams();
  const s = useTadweer();
  const [qty, setQty] = useState("");
  const [paying, setPaying] = useState(false);
  const [deal, setDeal] = useState<Deal | null>(null);

  if (!s) return <div className="mx-auto max-w-3xl px-4 py-10"><div className="h-80 rounded-2xl skeleton-shimmer" /></div>;
  const l = s.listings.find((x) => x.id === id);

  if (deal) return (
    <div className="mx-auto max-w-lg px-4 py-14 text-center">
      <motion.div initial={{ scale: 0, rotate: -90 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring" }}><CheckCircle2 className="mx-auto h-20 w-20 text-primary" /></motion.div>
      <h1 className="mt-4 text-2xl font-extrabold">تمت الصفقة بنجاح 🎉</h1>
      <div className="mt-6 space-y-2 rounded-2xl border bg-card p-5 text-right shadow-soft">
        <R a="رقم الصفقة" b={deal.id} /><R a="النوع" b={WASTE_TYPES[deal.type].label} /><R a="الكمية" b={tons(deal.tons)} />
        <R a="الإجمالي" b={money(deal.total)} /><R a="عمولة المنصة" b={money(deal.commission)} /><R a="يحصل الفلاح على" b={money(deal.farmerGets)} />
        <R a="CO₂ تم تجنبه" b={`${num(deal.co2Kg / 1000)} طن`} />
      </div>
      <Button asChild className="mt-6"><Link to="/browse">العودة للتصفح</Link></Button>
    </div>
  );

  if (!l || l.tons <= 0) return <div className="mx-auto max-w-md px-4 py-16 text-center"><p className="text-lg font-semibold">هذا الإعلان غير متاح.</p><Button asChild className="mt-4"><Link to="/browse">تصفح الإعلانات</Link></Button></div>;

  const q = +qty || 0;
  const invalid = q <= 0 || q > l.tons;
  const total = q * l.pricePerTon;
  const commission = Math.round(total * COMMISSION_RATE);
  const co2 = q * WASTE_TYPES[l.type].co2PerTon;

  function confirm() {
    setPaying(true);
    setTimeout(() => { setDeal(completeDeal(l!, q)); setPaying(false); }, 1400);
  }

  return (
    <div className="mx-auto grid max-w-5xl gap-6 px-4 py-10 lg:grid-cols-[1fr_360px]">
      <div className="rounded-2xl border bg-card p-6 shadow-soft">
        <h1 className="text-2xl font-extrabold">إتمام الصفقة</h1>
        <p className="mt-1 text-muted-foreground">{WASTE_TYPES[l.type].label} — {l.governorate} — {money(l.pricePerTon)}/طن — المتاح {tons(l.tons)}</p>
        <label className="mt-5 block"><span className="mb-1 block font-semibold">الكمية المطلوبة (طن)</span>
          <input className="field" inputMode="decimal" value={qty} onChange={(e) => setQty(e.target.value)} />
          {q > l.tons && <span className="mt-1 block text-sm text-destructive">الكمية تتجاوز المتاح ({tons(l.tons)})</span>}
        </label>
        <div className="mt-5 space-y-2 rounded-xl bg-muted p-4">
          <R a="القيمة الإجمالية" b={money(total)} /><R a="عمولة المنصة (4%)" b={money(commission)} /><R a="ما يحصل عليه الفلاح" b={money(total - commission)} />
          <R a="CO₂ تم تجنبه (تقديري)" b={`${num(co2 / 1000)} طن`} />
        </div>
        <div className="mt-5 rounded-xl border-2 border-dashed border-sand p-4">
          <p className="flex items-center gap-2 font-bold"><CreditCard className="h-5 w-5" /> الدفع</p>
          <p className="text-sm text-ember font-semibold">محاكاة - بدون دفع حقيقي</p>
        </div>
        <Button size="lg" disabled={invalid || paying} onClick={confirm} className="mt-5 min-h-12 w-full bg-gradient-primary text-base">
          {paying ? <><Loader2 className="h-5 w-5 animate-spin" /> جارٍ التأكيد…</> : "تأكيد الصفقة"}
        </Button>
      </div>
      <AiAdvice context="buyer" wasteLabel={WASTE_TYPES[l.type].label} tons={q || l.tons} governorate={l.governorate} pricePerTon={l.pricePerTon} />
    </div>
  );
}

function R({ a, b }: { a: string; b: string }) {
  return <div className="flex justify-between gap-3 text-sm"><span className="text-muted-foreground">{a}</span><span className="font-bold">{b}</span></div>;
}

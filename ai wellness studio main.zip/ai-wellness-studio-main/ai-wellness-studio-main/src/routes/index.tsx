import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Flame, Leaf, Upload, MessagesSquare, Handshake, Wind, Coins, Package, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Scene3D } from "@/components/Scene3D";
import { Reveal } from "@/components/Reveal";
import { totals, useTadweer } from "@/lib/store";
import { money, num } from "@/lib/format";
import { CHALLENGE_AREAS } from "@/config/tadweer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "تدوير — بيع مخلفاتك الزراعية بدلاً من حرقها" },
      { name: "description", content: "سوق رقمي يربط الفلاحين المصريين بمصانع الأعلاف والأسمدة والطاقة الحيوية." },
      { property: "og:title", content: "تدوير — بيع مخلفاتك الزراعية بدلاً من حرقها" },
      { property: "og:description", content: "دخل أكثر للفلاح وهواء أنظف لمصر." },
    ],
  }),
  component: Home,
});

const STEPS = [
  { icon: Upload, title: "انشر", desc: "سجّل نوع المخلفات وكميتها وسعرك في دقيقة." },
  { icon: MessagesSquare, title: "تواصل", desc: "المصانع والمشترون يتصفحون ويطلبون الصفقة." },
  { icon: Handshake, title: "أتمم الصفقة", desc: "استلم أموالك — العمولة 4% فقط عند البيع." },
];

function Home() {
  const s = useTadweer();
  const t = s ? totals(s.deals) : null;
  const stats = [
    { icon: Package, label: "طن أُنقذ من الحرق", value: t ? num(t.tons) : "—" },
    { icon: Wind, label: "طن CO₂ تم تجنبه (تقديري)", value: t ? num(t.co2 / 1000) : "—" },
    { icon: Coins, label: "دخل حققه الفلاحون", value: t ? money(t.income) : "—" },
  ];
  return (
    <div>
      <section className="bg-hero">
        <div className="mx-auto grid max-w-6xl items-center gap-6 px-4 py-10 md:grid-cols-2 md:py-16">
          <div>
            <motion.span initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-sm font-semibold text-secondary-foreground">
              <Flame className="h-4 w-4 text-ember" /> كل موسم تُحرق ملايين الأطنان من القش
            </motion.span>
            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mt-4 text-4xl font-extrabold leading-tight md:text-6xl">
              لا تحرقها… <span className="text-gradient">بِعها</span>
            </motion.h1>
            <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-4 text-lg leading-8 text-muted-foreground">
              حرق المخلفات الزراعية يلوث الهواء ويضيّع على الفلاح دخلاً حقيقياً. تدوير يربطك مباشرة بمصانع الأعلاف والأسمدة العضوية والطاقة الحيوية.
            </motion.p>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-6 flex flex-wrap gap-3">
              <Button asChild size="lg" className="min-h-12 bg-gradient-primary px-6 text-base shadow-lift"><Link to="/post">انشر مخلفاتك</Link></Button>
              <Button asChild size="lg" variant="outline" className="min-h-12 px-6 text-base"><Link to="/browse">تصفح المخلفات <ArrowLeft className="h-4 w-4" /></Link></Button>
            </motion.div>
          </div>
          <Scene3D className="h-[340px] w-full md:h-[480px]" />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-4 sm:grid-cols-3">
          {stats.map((st, i) => (
            <Reveal key={st.label} delay={i * 0.1}>
              <div className="card-lift rounded-2xl border bg-card p-6 shadow-soft">
                <st.icon className="h-7 w-7 text-primary" />
                <div className="mt-3 text-3xl font-extrabold">{st.value}</div>
                <div className="text-sm text-muted-foreground">{st.label}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-secondary/50 py-14">
        <div className="mx-auto max-w-6xl px-4">
          <Reveal><h2 className="text-center text-3xl font-extrabold">كيف يعمل تدوير؟</h2></Reveal>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {STEPS.map((st, i) => (
              <Reveal key={st.title} delay={i * 0.15}>
                <div className="card-lift relative h-full rounded-2xl bg-card p-6 shadow-soft">
                  <span className="absolute left-5 top-5 text-5xl font-extrabold text-accent">{num(i + 1)}</span>
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-primary text-primary-foreground animate-float" style={{ animationDelay: `${i * 0.6}s` }}><st.icon className="h-6 w-6" /></span>
                  <h3 className="mt-4 text-xl font-bold">{st.title}</h3>
                  <p className="mt-1 text-muted-foreground">{st.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <Reveal><h2 className="text-3xl font-extrabold">مجالات التحدي التي ندعمها</h2></Reveal>
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {CHALLENGE_AREAS.map((c, i) => (
            <Reveal key={c.title} delay={i * 0.08}>
              <div className="card-lift h-full rounded-2xl border bg-card p-5">
                <Leaf className="h-6 w-6 text-primary-glow" />
                <h3 className="mt-2 font-bold">{c.title}</h3>
                <p className="text-sm text-muted-foreground">{c.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}

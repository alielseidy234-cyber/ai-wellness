import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell } from "recharts";
import { AiAdvice } from "@/components/AiAdvice";
import { Scene3D } from "@/components/Scene3D";
import { WASTE_TYPES, type WasteType } from "@/config/tadweer";
import { money, num } from "@/lib/format";

export const Route = createFileRoute("/calculator")({
  head: () => ({
    meta: [
      { title: "حاسبة الأثر — تدوير" },
      { name: "description", content: "احسب دخلك من بيع المخلفات وكمية التلوث التي تمنعها." },
      { property: "og:title", content: "حاسبة الأثر — تدوير" },
      { property: "og:description", content: "قارن بين البيع والحرق بالأرقام." },
    ],
  }),
  component: Calc,
});

function Calc() {
  const [type, setType] = useState<WasteType>("rice_straw");
  const [t, setT] = useState("20");
  const info = WASTE_TYPES[type];
  const n = Math.max(0, +t || 0);
  const income = n * ((info.priceMin + info.priceMax) / 2) * 0.96;
  const co2 = (n * info.co2PerTon) / 1000;
  const pm = n * info.pmPerTon;
  const data = [{ name: "البيع عبر تدوير", v: Math.round(income) }, { name: "الحرق", v: 0 }];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">حاسبة الأثر</h1>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="grid gap-3 rounded-2xl border bg-card p-5 shadow-soft sm:grid-cols-2">
            <label><span className="mb-1 block font-semibold">نوع المخلفات</span><select className="field" value={type} onChange={(e) => setType(e.target.value as WasteType)}>{Object.entries(WASTE_TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></label>
            <label><span className="mb-1 block font-semibold">الكمية (طن)</span><input className="field" inputMode="decimal" value={t} onChange={(e) => setT(e.target.value)} /></label>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            {[["دخل متوقع (صافي)", money(income)], ["CO₂ تم تجنبه", `${num(co2)} طن`], ["جسيمات PM2.5", `${num(pm)} كجم`]].map(([a, b], i) => (
              <motion.div key={a} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="rounded-2xl bg-primary p-4 text-primary-foreground shadow-lift">
                <div className="text-xs opacity-80">{a}</div><motion.div key={b} initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="mt-1 text-xl font-extrabold">{b}</motion.div>
              </motion.div>
            ))}
          </div>
          <p className="rounded-xl bg-secondary p-4 leading-8 text-secondary-foreground">
            بدلاً من حرق {num(n)} طن من {info.label} وخسارة {money(income)}، يمكنك بيعها لاستخدامات مثل: {info.uses} — وتحمي هواء قريتك من {num(pm)} كجم من الجسيمات الضارة.
          </p>
          <div className="h-56 rounded-2xl border bg-card p-4">
            <ResponsiveContainer>
              <BarChart data={data}><XAxis dataKey="name" /><YAxis orientation="right" width={70} /><Tooltip formatter={(v) => money(Number(v ?? 0))} />
                <Bar dataKey="v" radius={[10, 10, 0, 0]} animationDuration={900}>{data.map((_, i) => <Cell key={i} fill={i ? "var(--ember)" : "var(--primary)"} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-muted-foreground">* أرقام الأثر تقديرية مؤقتة لأغراض النموذج الأولي.</p>
        </div>
        <div className="space-y-4">
          <Scene3D className="hidden h-72 w-full lg:block" />
          <AiAdvice context="calculator" wasteLabel={info.label} tons={n || 1} />
        </div>
      </div>
    </div>
  );
}

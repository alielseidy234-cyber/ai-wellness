import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AiAdvice } from "@/components/AiAdvice";
import { COMMISSION_RATE, GOVERNORATES, WASTE_TYPES, type WasteType } from "@/config/tadweer";
import { addListing } from "@/lib/store";
import { money } from "@/lib/format";

export const Route = createFileRoute("/post")({
  head: () => ({
    meta: [
      { title: "انشر مخلفاتك — تدوير" },
      { name: "description", content: "أضف مخلفاتك الزراعية للبيع واعرف دخلك المتوقع فوراً." },
      { property: "og:title", content: "انشر مخلفاتك — تدوير" },
      { property: "og:description", content: "بيع قش الأرز وحطب الذرة وغيرها بدلاً من حرقها." },
    ],
  }),
  component: PostPage,
});

function PostPage() {
  const [f, setF] = useState({ type: "rice_straw" as WasteType, tons: "", governorate: "", price: "", date: "", phone: "", notes: "", farmer: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [done, setDone] = useState(false);
  const info = WASTE_TYPES[f.type];
  const total = (+f.tons || 0) * (+f.price || 0);
  const commission = total * COMMISSION_RATE;
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (!(+f.tons > 0) || +f.tons > 10000) er["tons"] = "أدخل كمية صحيحة بالطن";
    if (!f.governorate) er["governorate"] = "اختر المحافظة";
    if (!(+f.price > 0)) er["price"] = "أدخل سعر الطن";
    if (!f.date) er["date"] = "حدد تاريخ التوفر";
    if (!/^01[0125]\d{8}$/.test(f.phone)) er["phone"] = "رقم موبايل مصري من 11 رقماً يبدأ بـ 01";
    if (f.farmer.trim().length < 2) er["farmer"] = "اكتب اسمك";
    setErrors(er);
    if (Object.keys(er).length) return;
    addListing({ type: f.type, tons: +f.tons, governorate: f.governorate, pricePerTon: +f.price, availableFrom: f.date, phone: f.phone, notes: f.notes.trim() || undefined, farmer: f.farmer.trim() });
    setDone(true);
  }

  if (done) return (
    <div className="mx-auto max-w-md px-4 py-16 text-center">
      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }}><CheckCircle2 className="mx-auto h-20 w-20 text-primary" /></motion.div>
      <h1 className="mt-4 text-2xl font-extrabold">تم نشر مخلفاتك بنجاح!</h1>
      <p className="mt-2 text-muted-foreground">إعلانك ظاهر الآن للمشترين. سنتواصل معك عند طلب صفقة.</p>
      <div className="mt-6 flex justify-center gap-3">
        <Button asChild><Link to="/browse">شاهد إعلانك</Link></Button>
        <Button variant="outline" onClick={() => { setDone(false); setF({ ...f, tons: "", price: "", notes: "" }); }}>انشر إعلاناً آخر</Button>
      </div>
    </div>
  );

  const Err = ({ k }: { k: string }) => errors[k] ? <p className="mt-1 text-sm text-destructive">{errors[k]}</p> : null;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">انشر مخلفاتك</h1>
      <p className="mt-2 flex items-center gap-2 text-sm text-primary"><ShieldCheck className="h-4 w-4" /> لا تدفع شيئاً إلا إذا بعت — العمولة 4% فقط عند إتمام الصفقة.</p>
      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_380px]">
        <form onSubmit={submit} noValidate className="grid gap-4 rounded-2xl border bg-card p-5 shadow-soft sm:grid-cols-2">
          <label className="sm:col-span-2"><span className="mb-1 block font-semibold">نوع المخلفات</span>
            <select className="field" value={f.type} onChange={set("type")}>
              {Object.entries(WASTE_TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
            <span className="mt-1 block text-xs text-muted-foreground">السعر المعتاد: {money(info.priceMin)} – {money(info.priceMax)} للطن</span>
          </label>
          <label><span className="mb-1 block font-semibold">الكمية (طن)</span><input className="field" inputMode="decimal" value={f.tons} onChange={set("tons")} /><Err k="tons" /></label>
          <label><span className="mb-1 block font-semibold">سعر الطن (جنيه)</span><input className="field" inputMode="decimal" value={f.price} onChange={set("price")} /><Err k="price" /></label>
          <label><span className="mb-1 block font-semibold">المحافظة</span>
            <select className="field" value={f.governorate} onChange={set("governorate")}><option value="">اختر…</option>{GOVERNORATES.map((g) => <option key={g}>{g}</option>)}</select><Err k="governorate" />
          </label>
          <label><span className="mb-1 block font-semibold">متاحة من تاريخ</span><input type="date" className="field" value={f.date} onChange={set("date")} /><Err k="date" /></label>
          <label><span className="mb-1 block font-semibold">الاسم</span><input className="field" value={f.farmer} onChange={set("farmer")} /><Err k="farmer" /></label>
          <label><span className="mb-1 block font-semibold">رقم الموبايل</span><input className="field" dir="ltr" inputMode="tel" placeholder="01xxxxxxxxx" value={f.phone} onChange={set("phone")} /><Err k="phone" /></label>
          <label className="sm:col-span-2"><span className="mb-1 block font-semibold">ملاحظات (اختياري)</span><textarea className="field min-h-24" value={f.notes} onChange={set("notes")} maxLength={300} /></label>
          <Button type="submit" size="lg" className="min-h-12 bg-gradient-primary text-base sm:col-span-2">انشر الإعلان</Button>
        </form>
        <div className="space-y-4">
          <div className="rounded-2xl bg-primary p-5 text-primary-foreground shadow-lift">
            <h3 className="font-bold">تقدير فوري لدخلك</h3>
            <div className="mt-3 space-y-2 text-sm">
              <Row a="قيمة البيع" b={money(total)} />
              <Row a="عمولة المنصة (4%)" b={`- ${money(commission)}`} />
              <div className="border-t border-primary-foreground/30 pt-2 text-lg font-extrabold"><Row a="صافي ما تحصل عليه" b={money(total - commission)} /></div>
            </div>
          </div>
          <AiAdvice context="farmer_post" wasteLabel={info.label} tons={+f.tons || 1} governorate={f.governorate || undefined} pricePerTon={+f.price || undefined} />
        </div>
      </div>
    </div>
  );
}

function Row({ a, b }: { a: string; b: string }) {
  return <div className="flex justify-between"><span>{a}</span><span className="font-bold">{b}</span></div>;
}

import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, Package, Search, CalendarDays, SearchX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { GOVERNORATES, WASTE_TYPES } from "@/config/tadweer";
import { useTadweer } from "@/lib/store";
import { money, tons } from "@/lib/format";

export const Route = createFileRoute("/browse")({
  head: () => ({
    meta: [
      { title: "تصفح المخلفات الزراعية — تدوير" },
      { name: "description", content: "ابحث عن قش الأرز ومصاص القصب وروث الحيوانات في كل محافظات مصر." },
      { property: "og:title", content: "تصفح المخلفات الزراعية — تدوير" },
      { property: "og:description", content: "خامات للأعلاف والأسمدة والطاقة الحيوية مباشرة من الفلاح." },
    ],
  }),
  component: Browse,
});

function Browse() {
  const s = useTadweer();
  const [q, setQ] = useState("");
  const [type, setType] = useState("");
  const [gov, setGov] = useState("");
  const [minQ, setMinQ] = useState("");
  const [maxP, setMaxP] = useState("");
  const [sort, setSort] = useState("new");

  const list = useMemo(() => {
    if (!s) return [];
    let l = s.listings.filter((x) => x.tons > 0);
    if (q) l = l.filter((x) => (WASTE_TYPES[x.type].label + x.governorate + x.farmer + (x.notes ?? "")).includes(q));
    if (type) l = l.filter((x) => x.type === type);
    if (gov) l = l.filter((x) => x.governorate === gov);
    if (+minQ) l = l.filter((x) => x.tons >= +minQ);
    if (+maxP) l = l.filter((x) => x.pricePerTon <= +maxP);
    return [...l].sort((a, b) => sort === "cheap" ? a.pricePerTon - b.pricePerTon : sort === "big" ? b.tons - a.tons : b.createdAt - a.createdAt);
  }, [s, q, type, gov, minQ, maxP, sort]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">تصفح المخلفات</h1>
      <div className="mt-5 grid gap-3 rounded-2xl border bg-card p-4 shadow-soft sm:grid-cols-2 lg:grid-cols-6">
        <div className="relative lg:col-span-2"><Search className="absolute right-3 top-3.5 h-5 w-5 text-muted-foreground" /><input className="field pr-10" placeholder="ابحث…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <select className="field" value={type} onChange={(e) => setType(e.target.value)}><option value="">كل الأنواع</option>{Object.entries(WASTE_TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select>
        <select className="field" value={gov} onChange={(e) => setGov(e.target.value)}><option value="">كل المحافظات</option>{GOVERNORATES.map((g) => <option key={g}>{g}</option>)}</select>
        <input className="field" inputMode="decimal" placeholder="أقل كمية (طن)" value={minQ} onChange={(e) => setMinQ(e.target.value)} />
        <input className="field" inputMode="decimal" placeholder="أقصى سعر للطن" value={maxP} onChange={(e) => setMaxP(e.target.value)} />
        <select className="field lg:col-span-6 lg:w-56" value={sort} onChange={(e) => setSort(e.target.value)}><option value="new">الأحدث</option><option value="cheap">الأرخص</option><option value="big">الأكبر كمية</option></select>
      </div>

      {!s ? (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="h-52 rounded-2xl skeleton-shimmer" />)}</div>
      ) : list.length === 0 ? (
        <div className="mt-12 text-center"><SearchX className="mx-auto h-14 w-14 text-muted-foreground" /><p className="mt-3 text-lg font-semibold">لا توجد نتائج مطابقة</p><p className="text-muted-foreground">جرّب تغيير الفلاتر أو البحث بكلمة أخرى.</p></div>
      ) : (
        <motion.div layout className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence>
            {list.map((l, i) => (
              <motion.div key={l.id} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ delay: Math.min(i, 8) * 0.04 }} className="card-lift flex flex-col rounded-2xl border bg-card p-5 shadow-soft">
                <div className="flex items-start justify-between">
                  <span className="rounded-full bg-accent px-3 py-1 text-sm font-bold text-accent-foreground">{WASTE_TYPES[l.type].label}</span>
                  <span className="text-xl font-extrabold text-primary">{money(l.pricePerTon)}<span className="text-xs font-normal text-muted-foreground"> /طن</span></span>
                </div>
                <div className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <p className="flex items-center gap-2"><Package className="h-4 w-4" /> {tons(l.tons)} متاحة</p>
                  <p className="flex items-center gap-2"><MapPin className="h-4 w-4" /> {l.governorate} — {l.farmer}</p>
                  <p className="flex items-center gap-2"><CalendarDays className="h-4 w-4" /> متاحة من {l.availableFrom}</p>
                </div>
                <Button asChild className="mt-5 min-h-11"><Link to="/deal/$id" params={{ id: l.id }}>اطلب الصفقة</Link></Button>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}

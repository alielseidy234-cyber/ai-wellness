import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Flame, Lightbulb, Wallet, Rocket, Users } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { totals, useTadweer } from "@/lib/store";
import { money, num } from "@/lib/format";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "عن المشروع ونموذج العمل — تدوير" },
      { name: "description", content: "المشكلة والحل ونموذج الإيرادات بعمولة 4% وخطط التوسع لمنصة تدوير." },
      { property: "og:title", content: "عن المشروع — تدوير" },
      { property: "og:description", content: "اقتصاد أخضر يبدأ من الحقل." },
    ],
  }),
  component: About,
});

const BLOCKS = [
  { icon: Flame, title: "المشكلة", text: "حرق قش الأرز والمخلفات الزراعية يسبب السحابة السوداء ويضيّع على الفلاح دخلاً يمكن تحقيقه." },
  { icon: Lightbulb, title: "الحل", text: "سوق رقمي بسيط يربط الفلاح بالمصانع التي تحتاج هذه المخلفات كخامات." },
  { icon: Wallet, title: "نموذج الإيرادات", text: "عمولة 4% على كل صفقة مكتملة فقط — لا رسوم مقدمة على الفلاح." },
  { icon: Rocket, title: "التوسع المستقبلي", text: "خدمة نقل وكبس، إعلانات مميزة، وعقود توريد موسمية." },
  { icon: Users, title: "العملاء", text: "مصانع الأعلاف، منتجو الأسمدة العضوية، ومحطات الطاقة الحيوية." },
];

function About() {
  const s = useTadweer();
  const t = s ? totals(s.deals) : null;
  const monthly = s ? Object.values(s.deals.reduce<Record<string, { m: string; c: number }>>((a, d) => {
    const k = new Date(d.createdAt).toISOString().slice(0, 7);
    a[k] = a[k] ?? { m: k, c: 0 }; a[k].c += d.commission; return a;
  }, {})).sort((a, b) => a.m.localeCompare(b.m)) : [];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">عن المشروع</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {BLOCKS.map((b, i) => (
          <Reveal key={b.title} delay={i * 0.08}>
            <div className="card-lift h-full rounded-2xl border bg-card p-6 shadow-soft">
              <b.icon className="h-7 w-7 text-primary" /><h2 className="mt-2 text-xl font-bold">{b.title}</h2><p className="mt-1 leading-7 text-muted-foreground">{b.text}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal className="mt-12">
        <div className="rounded-2xl border-2 border-primary/30 bg-card p-6">
          <h2 className="text-xl font-extrabold">لوحة الإدارة (Admin)</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-4">
            {[["إجمالي الصفقات", s ? num(s.deals.length) : "—"], ["إيراد العمولات", t ? money(t.commission) : "—"], ["أطنان أُنقذت", t ? num(t.tons) : "—"], ["CO₂ (طن)", t ? num(t.co2 / 1000) : "—"]].map(([a, b]) => (
              <div key={a} className="rounded-xl bg-muted p-4"><div className="text-xs text-muted-foreground">{a}</div><div className="text-xl font-extrabold">{b}</div></div>
            ))}
          </div>
          <div className="mt-5 h-60">
            <ResponsiveContainer><BarChart data={monthly}><XAxis dataKey="m" /><YAxis orientation="right" width={70} /><Tooltip formatter={(v) => money(Number(v ?? 0))} /><Bar dataKey="c" name="العمولة" fill="var(--primary)" radius={[8, 8, 0, 0]} /></BarChart></ResponsiveContainer>
          </div>
        </div>
      </Reveal>
    </div>
  );
}

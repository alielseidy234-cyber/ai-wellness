/**
 * إعدادات منصة تدوير — كل ثوابت العمل والأثر في مكان واحد.
 *
 * ⚠️ تنبيه: أرقام الأثر البيئي (CO2 والملوثات) أرقام تقديرية مؤقتة (placeholders)
 * لأغراض النموذج الأولي فقط، ويجب استبدالها ببيانات موثقة من مصادر علمية
 * (مثل جهاز شؤون البيئة المصري / IPCC / FAO) قبل الإطلاق الفعلي.
 */

export const COMMISSION_RATE = 0.04; // عمولة المنصة 4% على كل صفقة مكتملة
export const CURRENCY = "جنيه";

export type WasteType = "rice_straw" | "corn_stalks" | "bagasse" | "palm" | "manure";

export interface WasteInfo {
  label: string;
  /** كجم CO2 مكافئ يتم تجنبه لكل طن لا يُحرق (تقديري) */
  co2PerTon: number;
  /** كجم جسيمات دقيقة PM2.5 يتم تجنبها لكل طن (تقديري) */
  pmPerTon: number;
  /** نطاق السعر المقترح للطن بالجنيه */
  priceMin: number;
  priceMax: number;
  uses: string;
}

export const WASTE_TYPES: Record<WasteType, WasteInfo> = {
  rice_straw: { label: "قش الأرز", co2PerTon: 1460, pmPerTon: 8.3, priceMin: 600, priceMax: 1200, uses: "أعلاف، أسمدة عضوية، طاقة حيوية" },
  corn_stalks: { label: "حطب الذرة", co2PerTon: 1350, pmPerTon: 7.1, priceMin: 500, priceMax: 1000, uses: "أعلاف، كمبوست" },
  bagasse: { label: "مصاص القصب", co2PerTon: 1200, pmPerTon: 5.5, priceMin: 700, priceMax: 1500, uses: "طاقة حيوية، ورق، ألواح" },
  palm: { label: "مخلفات النخيل", co2PerTon: 1300, pmPerTon: 6.2, priceMin: 400, priceMax: 900, uses: "ألواح خشبية، فحم حيوي، أسمدة" },
  manure: { label: "روث الحيوانات", co2PerTon: 900, pmPerTon: 2.0, priceMin: 300, priceMax: 700, uses: "أسمدة عضوية، بيوجاز" },
};

export const GOVERNORATES = [
  "الشرقية", "الدقهلية", "كفر الشيخ", "البحيرة", "المنيا", "أسيوط",
  "الغربية", "المنوفية", "القليوبية", "الفيوم", "بني سويف", "سوهاج", "قنا", "الأقصر", "أسوان",
];

export const CHALLENGE_AREAS = [
  { title: "الزراعة المستدامة", desc: "تحويل المخلفات إلى قيمة بدلاً من الحرق." },
  { title: "إدارة المخلفات", desc: "سلسلة توريد منظمة للكتلة الحيوية." },
  { title: "جودة الهواء", desc: "تقليل السحابة السوداء والجسيمات الدقيقة." },
  { title: "الطاقة المتجددة", desc: "إمداد محطات الطاقة الحيوية بالخامات." },
  { title: "دخل الفلاح", desc: "مصدر دخل إضافي للأسر الريفية." },
];

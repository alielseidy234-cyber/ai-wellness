import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Loader2, RefreshCw } from "lucide-react";
import { getAiAdvice } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";

interface Props {
  context: "farmer_post" | "calculator" | "buyer";
  wasteLabel: string;
  tons: number;
  governorate?: string | undefined;
  pricePerTon?: number | undefined;
}

export function AiAdvice(p: Props) {
  const fn = useServerFn(getAiAdvice);
  const [loading, setLoading] = useState(false);
  const [tips, setTips] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    setLoading(true); setError(null);
    try {
      const r = await fn({ data: { context: p.context, wasteLabel: p.wasteLabel, tons: p.tons || 1, ...(p.governorate ? { governorate: p.governorate } : {}), ...(p.pricePerTon ? { pricePerTon: p.pricePerTon } : {}) } });
      if (r.ok) setTips(r.text.split("\n").map((l) => l.replace(/^\s*(-|\d+[.)])\s*/, "").trim()).filter(Boolean));
      else setError(r.error);
    } catch {
      setError("تعذر الاتصال بخدمة النصائح، حاول مرة أخرى.");
    } finally { setLoading(false); }
  }

  return (
    <div className="rounded-2xl border border-accent bg-gradient-ai p-5 shadow-soft">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <motion.span animate={{ rotate: [0, 15, -10, 0] }} transition={{ repeat: Infinity, duration: 3 }} className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-primary text-primary-foreground">
            <Sparkles className="h-5 w-5" />
          </motion.span>
          <div>
            <h3 className="font-bold">نصائح ذكية مخصصة</h3>
            <p className="text-xs text-muted-foreground">مولّدة بالذكاء الاصطناعي حسب بياناتك</p>
          </div>
        </div>
        <Button size="sm" onClick={run} disabled={loading} className="min-h-10">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : tips ? <RefreshCw className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
          {tips ? "نصائح جديدة" : "اطلب النصائح"}
        </Button>
      </div>
      <AnimatePresence mode="wait">
        {loading && (
          <motion.div key="l" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mt-4 space-y-2">
            {[0, 1, 2].map((i) => <div key={i} className="h-4 rounded skeleton-shimmer" style={{ width: `${90 - i * 15}%` }} />)}
            <p className="text-xs text-muted-foreground">الذكاء الاصطناعي يحلل حالتك…</p>
          </motion.div>
        )}
        {!loading && error && <motion.p key="e" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 text-sm text-destructive">{error}</motion.p>}
        {!loading && tips && (
          <motion.ul key="t" className="mt-4 space-y-2">
            {tips.map((t, i) => (
              <motion.li key={i} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.12 }} className="flex gap-2 rounded-xl bg-card/70 p-3 text-sm leading-7">
                <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-primary" />{t}
              </motion.li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  );
}

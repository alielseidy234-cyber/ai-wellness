import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Float, Lightformer, ContactShadows } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";

function strawTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const g = c.getContext("2d")!;
  g.fillStyle = "#d9b45a";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 900; i++) {
    g.strokeStyle = ["#c79a3e", "#e8c877", "#b88a33", "#f0d68e"][i % 4] ?? "#c79a3e";
    g.lineWidth = 1 + (i % 3);
    const x = (i * 97) % 256, y = (i * 53) % 256;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + 18 - (i % 36), y + 4); g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(3, 1);
  return t;
}

function HayBale({ position, rotation = 0, scale = 1, tex }: { position: [number, number, number]; rotation?: number; scale?: number; tex: THREE.Texture }) {
  return (
    <group position={position} rotation={[0, rotation, Math.PI / 2]} scale={scale}>
      <mesh castShadow>
        <cylinderGeometry args={[0.8, 0.8, 1.2, 28]} />
        <meshStandardMaterial map={tex} roughness={0.95} />
      </mesh>
      {[-0.25, 0.25].map((y) => (
        <mesh key={y} position={[0, y, 0]}>
          <torusGeometry args={[0.81, 0.03, 8, 32]} />
          <meshStandardMaterial color="#6b4a1f" />
        </mesh>
      ))}
    </group>
  );
}

function Leaf({ i, count }: { i: number; count: number }) {
  const ref = useRef<THREE.Group>(null);
  const shape = useMemo(() => {
    const s = new THREE.Shape();
    s.moveTo(0, 0);
    s.quadraticCurveTo(0.35, 0.35, 0, 0.9);
    s.quadraticCurveTo(-0.35, 0.35, 0, 0);
    return s;
  }, []);
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime() * 0.35 + (i / count) * Math.PI * 2;
    if (!ref.current) return;
    ref.current.position.set(Math.cos(t) * 3.1, 1.6 + Math.sin(t * 2) * 0.35, Math.sin(t) * 3.1);
    ref.current.rotation.set(t * 1.3, -t, Math.sin(t) * 0.6);
  });
  return (
    <group ref={ref}>
      <mesh castShadow>
        <shapeGeometry args={[shape]} />
        <meshStandardMaterial color={i % 2 ? "#4f9a4a" : "#77b85a"} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

function Island() {
  const ref = useRef<THREE.Group>(null);
  const tex = useMemo(() => strawTexture(), []);
  const stalks = useMemo(() => Array.from({ length: 26 }, (_, i) => {
    const a = (i / 26) * Math.PI * 2 + (i % 3) * 0.2;
    const r = 1.9 + (i % 4) * 0.12;
    return { x: Math.cos(a) * r, z: Math.sin(a) * r, h: 0.6 + (i % 5) * 0.12 };
  }), []);
  useFrame((_, d) => { if (ref.current) ref.current.rotation.y += Math.min(d, 0.05) * 0.18; });
  return (
    <group ref={ref}>
      <mesh position={[0, -0.35, 0]} receiveShadow>
        <cylinderGeometry args={[2.6, 2.2, 0.5, 40]} />
        <meshStandardMaterial color="#6ea24f" roughness={0.9} />
      </mesh>
      <mesh position={[0, -0.95, 0]}>
        <cylinderGeometry args={[2.2, 1.1, 0.8, 40]} />
        <meshStandardMaterial color="#8a6238" roughness={1} />
      </mesh>
      <HayBale position={[-0.7, 0.7, 0.2]} rotation={0.4} tex={tex} />
      <HayBale position={[0.9, 0.6, -0.4]} rotation={-0.8} scale={0.85} tex={tex} />
      <HayBale position={[0.2, 0.55, 1.1]} rotation={1.4} scale={0.7} tex={tex} />
      {stalks.map((s, i) => (
        <mesh key={i} position={[s.x, s.h / 2 - 0.1, s.z]} castShadow>
          <coneGeometry args={[0.05, s.h, 5]} />
          <meshStandardMaterial color={i % 3 ? "#c9a54b" : "#9cbf5c"} />
        </mesh>
      ))}
      {/* recycle ring */}
      <mesh position={[0, 1.6, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[3.1, 0.015, 8, 120]} />
        <meshStandardMaterial color="#2f6b3f" transparent opacity={0.35} />
      </mesh>
    </group>
  );
}

export default function FarmScene() {
  return (
    <Canvas shadows dpr={[1, 1.75]} camera={{ position: [0, 3.2, 7.5], fov: 42 }}>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 8, 4]} intensity={1.6} castShadow shadow-mapSize-width={1024} shadow-mapSize-height={1024} />
      <Environment>
        <Lightformer intensity={2} position={[0, 5, 0]} scale={[10, 10, 1]} />
        <Lightformer intensity={1} color="#ffe7b0" position={[-5, 1, -1]} rotation-y={Math.PI / 2} scale={[20, 1, 1]} />
      </Environment>
      <Float speed={1.4} rotationIntensity={0.15} floatIntensity={0.6}>
        <Island />
      </Float>
      {Array.from({ length: 8 }, (_, i) => <Leaf key={i} i={i} count={8} />)}
      <ContactShadows position={[0, -1.8, 0]} opacity={0.3} scale={10} blur={2.5} far={4} />
    </Canvas>
  );
}

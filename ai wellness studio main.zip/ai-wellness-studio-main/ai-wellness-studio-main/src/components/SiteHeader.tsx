import { Link } from "@tanstack/react-router";
import { Home, PlusCircle, Search, Calculator, Info, Recycle } from "lucide-react";
import { setRole, useTadweer } from "@/lib/store";

const NAV = [
  { to: "/", label: "الرئيسية", icon: Home },
  { to: "/post", label: "انشر مخلفاتك", icon: PlusCircle },
  { to: "/browse", label: "تصفح المخلفات", icon: Search },
  { to: "/calculator", label: "حاسبة الأثر", icon: Calculator },
  { to: "/about", label: "عن المشروع", icon: Info },
] as const;

function RoleSwitch() {
  const s = useTadweer();
  const role = s?.role ?? "farmer";
  return (
    <div className="flex rounded-full bg-secondary p-1 text-sm">
      {(["farmer", "buyer"] as const).map((r) => (
        <button key={r} onClick={() => setRole(r)} className={`rounded-full px-3 py-1.5 font-semibold transition-colors ${role === r ? "bg-primary text-primary-foreground shadow-soft" : "text-secondary-foreground"}`}>
          {r === "farmer" ? "أنا فلاح" : "أنا مشتري"}
        </button>
      ))}
    </div>
  );
}

export function SiteHeader() {
  return (
    <>
      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
          <Link to="/" className="flex items-center gap-2 text-xl font-extrabold text-primary">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-primary text-primary-foreground"><Recycle className="h-5 w-5" /></span>
            تدوير
          </Link>
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }} className="rounded-lg px-3 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-primary" activeProps={{ className: "bg-accent text-accent-foreground" }}>
                {n.label}
              </Link>
            ))}
          </nav>
          <RoleSwitch />
        </div>
      </header>
      <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t bg-background/95 backdrop-blur md:hidden">
        {NAV.map((n) => (
          <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }} className="flex min-h-16 flex-col items-center justify-center gap-1 text-[11px] font-semibold text-muted-foreground" activeProps={{ className: "text-primary" }}>
            <n.icon className="h-5 w-5" />{n.label.split(" ")[0]}
          </Link>
        ))}
      </nav>
    </>
  );
}

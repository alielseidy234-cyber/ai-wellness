import { ClientOnly } from "@tanstack/react-router";
import { lazy, Suspense } from "react";

const FarmScene = lazy(() => import("./FarmScene"));

export function Scene3D({ className = "" }: { className?: string }) {
  const fallback = <div className={`${className} rounded-3xl skeleton-shimmer opacity-40`} />;
  return (
    <ClientOnly fallback={fallback}>
      <Suspense fallback={fallback}>
        <div className={className}><FarmScene /></div>
      </Suspense>
    </ClientOnly>
  );
}
